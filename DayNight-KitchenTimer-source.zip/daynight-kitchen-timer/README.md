# Day&Night – Kitchen Timer (Android)

A simple dark-mode kitchen timer app. Includes starter tiles (rice, pasta, soup, eggs), custom timers, one-tap start, persistent exact alarm scheduling, a looping alarm sound, a full-screen alarm screen and a stop action.

## Build a free APK in GitHub Actions
1. Create a GitHub repository and upload the contents of this folder.
2. Open the repository's **Actions** tab.
3. Run **Build Android APK** (or push to `main`).
4. Open the completed workflow run and download the `DayNight-KitchenTimer-debug` artifact.
5. Extract the ZIP and install `app-debug.apk` on your Android phone.

## Android permissions
The app asks for notification permission on Android 13+. Android 12+ may also ask you to allow exact alarms. Grant both for reliable timer alerts. Some manufacturers' battery-management settings can still restrict background behavior; allow the app to run without battery restrictions if alarms are delayed.

## Notes
This is an initial MVP/debug build, not a Play Store release. A Play Store release needs a signed release build, store listing, privacy/data-safety declarations and testing. The splash screen is currently represented by the branded in-app header; the requested 2-second splash and 3-second 24-hour clock animation can be added in the next iteration.
