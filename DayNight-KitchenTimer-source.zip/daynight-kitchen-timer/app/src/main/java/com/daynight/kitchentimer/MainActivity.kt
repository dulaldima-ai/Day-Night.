package com.daynight.kitchentimer

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.max

private val Bg = Color(0xFF101114)
private val Panel = Color(0xFF1B1D22)
private val Gold = Color(0xFFD8B56D)
private val Muted = Color(0xFF9A9DA6)

data class KitchenTimer(val id: Int, val name: String, val seconds: Int)

class MainActivity : ComponentActivity() {
    private val askNotifications = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val prefs by lazy { getSharedPreferences("daynight", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent { DayNightApp() }
    }

    private fun loadTimers(): List<KitchenTimer> {
        val raw = prefs.getString("timers", null)
        if (raw == null) {
            val initial = listOf(KitchenTimer(1, "Ryż", 12 * 60), KitchenTimer(2, "Makaron", 9 * 60), KitchenTimer(3, "Zupa", 20 * 60), KitchenTimer(4, "Jajka", 7 * 60))
            saveTimers(initial)
            return initial
        }
        return raw.split("|").mapNotNull { row ->
            val p = row.split("~")
            if (p.size == 3) runCatching { KitchenTimer(p[0].toInt(), p[1], p[2].toInt()) }.getOrNull() else null
        }
    }

    private fun saveTimers(items: List<KitchenTimer>) {
        prefs.edit().putString("timers", items.joinToString("|") { "${it.id}~${it.name.replace("|", "").replace("~", "")}~${it.seconds}" }).apply()
    }

    private fun schedule(timer: KitchenTimer) {
        val alarmManager = getSystemService(ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= 31 && !alarmManager.canScheduleExactAlarms()) {
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            return
        }
        val endAt = System.currentTimeMillis() + timer.seconds * 1000L
        val intent = Intent(this, TimerReceiver::class.java).putExtra("name", timer.name)
        val pending = PendingIntent.getBroadcast(this, timer.id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        if (Build.VERSION.SDK_INT >= 23) alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, endAt, pending)
        else alarmManager.setExact(AlarmManager.RTC_WAKEUP, endAt, pending)
        prefs.edit().putString("active_name", timer.name).putLong("active_end", endAt).putInt("active_id", timer.id).apply()
    }

    @Composable private fun DayNightApp() {
        var timers by remember { mutableStateOf(loadTimers()) }
        var showAdd by remember { mutableStateOf(false) }
        var selected by remember { mutableStateOf<KitchenTimer?>(null) }
        var remaining by remember { mutableLongStateOf(0L) }
        var running by remember { mutableStateOf(false) }
        var splash by remember { mutableStateOf(true) }
        var clockStarted by remember { mutableStateOf(false) }
        var activeName by remember { mutableStateOf("") }

        LaunchedEffect(Unit) {
            delay(2000)
            clockStarted = true
            delay(3000)
            splash = false
            val end = prefs.getLong("active_end", 0L)
            if (end > System.currentTimeMillis()) {
                remaining = end - System.currentTimeMillis(); activeName = prefs.getString("active_name", "") ?: ""; running = true
            }
        }
        LaunchedEffect(running, remaining) {
            while (running && remaining > 0) { delay(1000); remaining = max(0, remaining - 1000) }
        }

        MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Gold, onBackground = Color.White, onSurface = Color.White)) {
            Surface(Modifier.fillMaxSize(), color = Bg) {
                if (splash) {
                    SplashScreen(clockStarted)
                } else Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("DAY&NIGHT", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                            Text("Kitchen Timer", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Icon(Icons.Default.Alarm, null, tint = Gold, modifier = Modifier.size(32.dp))
                    }
                    Spacer(Modifier.height(26.dp))
                    if (running || remaining > 0) {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("AKTYWNY TIMER", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
                                Text(activeName, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Medium)
                                Text(formatTime(remaining), color = Gold, fontSize = 48.sp, fontWeight = FontWeight.Light)
                                Text(if (running) "Odliczanie trwa również po zminimalizowaniu aplikacji" else "Timer zatrzymany", color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center)
                                Spacer(Modifier.height(12.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    OutlinedButton(onClick = { running = false; val id = prefs.getInt("active_id", -1); if (id >= 0) { val am = getSystemService(ALARM_SERVICE) as AlarmManager; val pi = PendingIntent.getBroadcast(this@MainActivity, id, Intent(this@MainActivity, TimerReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE); am.cancel(pi) }; prefs.edit().putLong("active_end", 0).apply(); remaining = 0 }, colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)) { Text("ZATRZYMAJ") }
                                }
                            }
                        }
                        Spacer(Modifier.height(24.dp))
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Twoje timery", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                            Text("Dotknij kafelka, aby od razu rozpocząć", color = Muted, fontSize = 12.sp)
                        }
                        FilledIconButton(onClick = { showAdd = true }, colors = IconButtonDefaults.filledIconButtonColors(containerColor = Gold, contentColor = Bg)) { Icon(Icons.Default.Add, "Dodaj timer") }
                    }
                    Spacer(Modifier.height(14.dp))
                    LazyVerticalGrid(columns = GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.weight(1f)) {
                        items(timers, key = { it.id }) { timer ->
                            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth().clickable {
                                schedule(timer); selected = timer; activeName = timer.name; remaining = timer.seconds * 1000L; running = true
                            }) {
                                Column(Modifier.padding(16.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Alarm, null, tint = Gold, modifier = Modifier.size(20.dp))
                                        Spacer(Modifier.weight(1f))
                                        Icon(Icons.Default.Delete, "Usuń ${timer.name}", tint = Muted, modifier = Modifier.size(18.dp).clickable { timers = timers.filterNot { it.id == timer.id }; saveTimers(timers) })
                                    }
                                    Spacer(Modifier.height(18.dp))
                                    Text(timer.name, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                    Text(formatSeconds(timer.seconds), color = Gold, fontSize = 15.sp)
                                    Spacer(Modifier.height(8.dp))
                                    Text("DOTKNIJ, ABY START", color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
                                }
                            }
                        }
                    }
                    Text("DAY&NIGHT  •  GOTUJ BEZ PILNOWANIA CZASU", color = Color(0xFF62656D), fontSize = 9.sp, letterSpacing = 1.sp, modifier = Modifier.fillMaxWidth().padding(top = 12.dp), textAlign = TextAlign.Center)
                }
            }
            if (!splash && showAdd) AddTimerDialog(onDismiss = { showAdd = false }, onSave = { name, seconds ->
                val next = (timers.maxOfOrNull { it.id } ?: 0) + 1
                timers = timers + KitchenTimer(next, name, seconds); saveTimers(timers); showAdd = false
            })
        }
    }
}


@Composable private fun SplashScreen(clockStarted: Boolean) {
    val rotation by animateFloatAsState(targetValue = if (clockStarted) 360f else 0f, animationSpec = tween(durationMillis = 3000), label = "clockRotation")
    Column(Modifier.fillMaxSize().background(Bg), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("DAY&NIGHT", color = Gold, fontSize = 30.sp, fontWeight = FontWeight.Bold, letterSpacing = 6.sp)
        Spacer(Modifier.height(10.dp))
        Text("KITCHEN TIMER", color = Muted, fontSize = 11.sp, letterSpacing = 4.sp)
        Spacer(Modifier.height(52.dp))
        Box(Modifier.size(132.dp), contentAlignment = Alignment.Center) {
            Text("◷", color = Gold, fontSize = 112.sp, modifier = Modifier.graphicsLayer { rotationZ = rotation })
        }
    }
}

@Composable private fun AddTimerDialog(onDismiss: () -> Unit, onSave: (String, Int) -> Unit) {
    var name by remember { mutableStateOf("") }
    var minutes by remember { mutableStateOf("5") }
    var seconds by remember { mutableStateOf("0") }
    AlertDialog(onDismissRequest = onDismiss, containerColor = Panel, title = { Text("Nowy timer", color = Color.White) }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Co gotujesz?", color = Muted) }, singleLine = true)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = minutes, onValueChange = { minutes = it.filter(Char::isDigit).take(3) }, label = { Text("Minuty") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                OutlinedTextField(value = seconds, onValueChange = { seconds = it.filter(Char::isDigit).take(2) }, label = { Text("Sekundy") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
            }
        }
    }, confirmButton = { TextButton(onClick = { val total = (minutes.toIntOrNull() ?: 0) * 60 + (seconds.toIntOrNull() ?: 0); if (name.isNotBlank() && total > 0) onSave(name.trim(), total) }) { Text("ZAPISZ", color = Gold) } }, dismissButton = { TextButton(onClick = onDismiss) { Text("ANULUJ", color = Muted) } })
}

fun formatTime(ms: Long): String { val s = (ms / 1000).coerceAtLeast(0); return String.format(Locale.getDefault(), "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60) }
fun formatSeconds(seconds: Int): String = String.format(Locale.getDefault(), "%02d:%02d", seconds / 60, seconds % 60)
