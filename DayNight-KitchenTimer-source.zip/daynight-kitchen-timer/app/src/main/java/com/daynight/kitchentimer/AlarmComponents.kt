package com.daynight.kitchentimer

import android.app.*
import android.content.*
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.IBinder
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class TimerReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val name = intent.getStringExtra("name") ?: "Timer"
        context.startForegroundService(Intent(context, AlarmSoundService::class.java).putExtra("name", name))
        val full = PendingIntent.getActivity(context, 9001, Intent(context, AlarmActivity::class.java).putExtra("name", name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "daynight_alarm"
        if (Build.VERSION.SDK_INT >= 26 && manager.getNotificationChannel(channelId) == null) {
            manager.createNotificationChannel(NotificationChannel(channelId, "Alarm timera", NotificationManager.IMPORTANCE_HIGH).apply { setSound(null, null); lockscreenVisibility = Notification.VISIBILITY_PUBLIC })
        }
        val notification = Notification.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Day&Night – czas minął!")
            .setContentText("$name jest gotowe")
            .setCategory(Notification.CATEGORY_ALARM)
            .setPriority(Notification.PRIORITY_MAX)
            .setFullScreenIntent(full, true)
            .setContentIntent(full)
            .setAutoCancel(false)
            .build()
        manager.notify(7001, notification)
    }
}

class AlarmSoundService : Service() {
    private var player: MediaPlayer? = null
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val name = intent?.getStringExtra("name") ?: "Timer"
        val channelId = "daynight_alarm"
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26 && manager.getNotificationChannel(channelId) == null) manager.createNotificationChannel(NotificationChannel(channelId, "Alarm timera", NotificationManager.IMPORTANCE_HIGH).apply { setSound(null, null) })
        val stopIntent = PendingIntent.getBroadcast(this, 9002, Intent(this, StopAlarmReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = Notification.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Day&Night – $name")
            .setContentText("Timer zakończony. Dotknij, aby wyłączyć alarm.")
            .addAction(Notification.Action.Builder(null, "WYŁĄCZ", stopIntent).build())
            .setOngoing(true).build()
        startForeground(7001, notification)
        if (player == null) {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            player = MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                setDataSource(this@AlarmSoundService, uri)
                isLooping = true
                prepare()
                start()
            }
        }
        return START_STICKY
    }
    override fun onDestroy() { player?.stop(); player?.release(); player = null; super.onDestroy() }
}

class StopAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        context.stopService(Intent(context, AlarmSoundService::class.java))
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(7001)
    }
}

class AlarmActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        val name = intent.getStringExtra("name") ?: "Timer"
        setShowWhenLocked(true); setTurnScreenOn(true)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = Color(0xFF101114), primary = Color(0xFFD8B56D))) {
                Surface(Modifier.fillMaxSize(), color = Color(0xFF101114)) {
                    Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Text("DAY&NIGHT", color = Color(0xFFD8B56D), fontSize = 14.sp, letterSpacing = 4.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(42.dp))
                        Text("⏰", fontSize = 76.sp)
                        Spacer(Modifier.height(24.dp))
                        Text("GOTOWE!", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                        Text(name, color = Color(0xFFD8B56D), fontSize = 24.sp)
                        Spacer(Modifier.height(50.dp))
                        Button(onClick = { stopAlarm(); finish() }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD8B56D), contentColor = Color(0xFF101114)), modifier = Modifier.fillMaxWidth().height(58.dp), shape = RoundedCornerShape(18.dp)) { Text("WYŁĄCZ ALARM", fontWeight = FontWeight.Bold) }
                    }
                }
            }
        }
    }
    private fun stopAlarm() {
        stopService(Intent(this, AlarmSoundService::class.java))
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(7001)
    }
}
